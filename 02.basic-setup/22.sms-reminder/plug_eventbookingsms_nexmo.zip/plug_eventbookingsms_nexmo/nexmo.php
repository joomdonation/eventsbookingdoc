<?php
/**
 * @package            Joomla
 * @subpackage         Event Booking
 * @author             Tuan Pham Ngoc
 * @copyright          Copyright (C) 2010 - 2020 Ossolution Team
 * @license            GNU/GPL, see LICENSE.php
 */

defined('_JEXEC') or die;

class plgEventbookingSMSNexmo extends JPlugin
{
	public function onEBSendingSMSReminder($rows)
	{
		require_once JPATH_ROOT . '/plugins/eventbookingsms/nexmo/nexmo/vendor/autoload.php';

		$apiKey    = $this->params->get('api_key');
		$apiSecret = $this->params->get('api_secret');
		$brandName = $this->params->get('brand_name');

		if (!$apiKey || !$apiSecret || !$brandName)
		{
			return;
		}

		$basic  = new \Nexmo\Client\Credentials\Basic($apiKey, $apiSecret);
		$client = new \Nexmo\Client($basic);

		foreach ($rows as $row)
		{
			try
			{

				$response = $client->sms()->send(
					new \Nexmo\SMS\Message\SMS($row->phone, $brandName, $row->sms_message)
				);

				$message = $response->current();

				if ($message->getStatus() !== 0)
				{
					EventbookingHelper::logData(__DIR__ . '/clickatell_error.txt', ['id' => $row->id, 'phone' => $row->phone, 'status' => $message->getStatus()]);
				}
			}
			catch (Exception $e)
			{
				EventbookingHelper::logData(__DIR__ . '/clickatell_error.txt', ['id' => $row->id, 'phone' => $row->phone, 'error' => $e->getMessage()]);
			}
		}

		// Return true to tell the system that SMS were successfully sent so that it could update sms sending status for registrants
		return true;
	}
}