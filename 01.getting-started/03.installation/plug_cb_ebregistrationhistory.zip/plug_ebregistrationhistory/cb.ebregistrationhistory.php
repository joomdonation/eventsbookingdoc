<?php
/**
 * @package            Joomla
 * @subpackage         Event Booking
 * @author             Tuan Pham Ngoc
 * @copyright          Copyright (C) 2010 - 2025 Ossolution Team
 * @license            GNU/GPL, see LICENSE.php
 */

\defined('_JEXEC') or die;

Use Joomla\CMS\User\User;
use Joomla\CMS\Factory;
use Joomla\Language\Text;
use Joomla\CMS\Router\Route;

class getEBRegistrationHistoryTab extends cbTabHandler
{
	/**
	 * Constructor
	 */
	public function __construct()
	{
		$this->cbTabHandler();
	}

	/**
	 * Display registration history of a user
	 *
	 * @param   object  $tab
	 * @param   User    $user
	 * @param   int     $ui
	 *
	 * @return string
	 */
	public function getDisplayTab($tab, $user, $ui)
	{
		// Require libraries
		require_once JPATH_ADMINISTRATOR . '/components/com_eventbooking/libraries/rad/bootstrap.php';

		$config = EventbookingHelper::getConfig();
		$params = $this->params;

		/* @var \Joomla\Database\DatabaseInterface $db */
		$db     = Factory::getContainer()->get('db');
		$query  = $db->getQuery(true);
		$query->select('COUNT(*)')
			->from('#__eb_registrants')
			->where('user_id = ' . (int) $user->id)
			->where('(published >= 1 OR payment_method LIKE "os_offline%")');
		$db->setQuery($query);
		$total = $db->loadResult();

		$numberRegistrants = $params->get('number_records', 10);
		$pagingParams      = $this->_getPaging(array(), array("entries_"));

		if ($pagingParams["entries_limitstart"] === null)
		{
			$pagingParams["entries_limitstart"] = "0";
		}

		if ($numberRegistrants > $total)
		{
			$pagingParams["entries_limitstart"] = "0";
		}

		$limitStart = $pagingParams["entries_limitstart"] ?: "0";

		$query->clear()
			->select('a.*, b.title AS event_title, b.event_date, b.currency_symbol')
			->from('#__eb_registrants AS a')
			->innerJoin('#__eb_events AS b ON a.event_id = b.id')
			->where('a.user_id = ' . (int) $user->id)
			->where('(a.published >= 1 OR a.payment_method LIKE "os_offline%")');

		if (!$config->get('include_group_billing_in_registrants', 1))
		{
			$query->where('a.is_group_billing = 0 ');
		}

		if (!$config->include_group_members_in_registrants)
		{
			$query->where('a.group_id = 0');
		}

		$db->setQuery($query);
		$db->setQuery($query, $limitStart, $numberRegistrants);

		$rows = $db->loadObjectList();

		ob_start();
		$this->drawRegistrationHistory($rows, $pagingParams, $numberRegistrants, $total);

		return ob_get_clean();
	}

	/**
	 * Draw the output for donation history
	 *
	 * @param array $rows
	 */
	private function drawRegistrationHistory($rows, $pagingParams, $numberRegistrants, $total)
	{
		$config = EventbookingHelper::getConfig();
		$itemId     = EventbookingHelper::getItemid();
		EventbookingHelper::loadLanguage();

		if (count($rows))
		{
			$cols = 5;
			?>
			<table width="100%" cellspacing="3" cellpadding="3" class="table table-striped table-bordered table-hover eb_registration_history">
				<thead>
				<tr>
					<th>
						<?php echo Text::_('EB_EVENT'); ?>
					</th>
					<?php
					if ($config->show_event_date)
					{
						$cols++;
						?>
						<th>
							<?php echo Text::_('EB_EVENT_DATE'); ?>
						</th>
						<?php
					}
					?>
					<th>
						<?php echo Text::_('EB_NUMBER_REGISTRANTS'); ?>
					</th>
					<th>
						<?php echo Text::_('EB_REGISTRATION_DATE'); ?>
					</th>
					<th>
						<?php echo Text::_('EB_AMOUNT'); ?>
					</th>
					<?php
					if ($config->activate_invoice_feature)
					{
						$cols++;
						?>
						<th><?php echo Text::_('EB_INVOICE_NUMBER'); ?></th>
						<?php
					}
					?>
					<th>
						<?php echo Text::_('EB_REGISTRATION_STATUS'); ?>
					</th>
				</tr>
				</thead>
				<tbody>
				<?php
				for ($i = 0, $n = count($rows); $i < $n; $i++)
				{
					$row = $rows[$i];

					if ($row->event_detail_url)
					{
						$eventLink = $row->event_detail_url;
					}
					else
					{
						$eventLink = Route::_(EventbookingHelperRoute::getEventRoute($row->event_id, $row->main_category_id, $itemId));
					}

					?>
					<tr>
						<td>
							<a href="<?php echo $eventLink; ?>"><?php echo $row->event_title; ?></a>
						</td>
						<?php
						if ($config->show_event_date)
						{
						?>
							<td>
								<?php echo JHtml::_('date', $row->event_date, $config->date_format, null) ; ?>
							</td>
						<?php
						}
						?>
						<td align="center">
							<?php echo $row->number_registrants; ?>
						</td>
						<td>
							<?php echo JHtml::_('date', $row->register_date, $config->date_format); ?>
						</td>
						<td align="right">
							<?php echo EventbookingHelper::formatCurrency($row->amount, $config, $row->currency_symbol) ; ?>
						</td>
						<?php
						if ($config->activate_invoice_feature)
						{
						?>
							<td class="center">
								<?php
								if ($row->invoice_number)
								{
									?>
									<a href="<?php echo Route::_('index.php?option=com_eventbooking&task=registrant.download_invoice&id='.($row->cart_id ? $row->cart_id : ($row->group_id ? $row->group_id : $row->id))); ?>" title="<?php echo JText::_('EB_DOWNLOAD'); ?>"><?php echo EventbookingHelper::formatInvoiceNumber($row->invoice_number, $config) ; ?></a>
									<?php
								}
								?>
							</td>
						<?php
						}
						?>
						<td class="center">
							<?php
							switch($row->published)
							{
								case 0 :
									echo Text::_('EB_PENDING');
									break ;
								case 1 :
									echo Text::_('EB_PAID');
									break ;
								case 2 :
									echo Text::_('EB_CANCELLED');
									break;
								case 3:
									echo Text::_('EB_WAITING_LIST');
									break;
							}
							?>
						</td>
					</tr>
					<?php
				}
				?>
				</tbody>
				<?php
				if ($total > $numberRegistrants)
				{
				?>
					<tfoot>
					<tr>
						<td colspan="<?php echo $cols; ?>">
							<div class="pagination"><?php echo $this->_writePaging($pagingParams, "entries_", $numberRegistrants, $total); ?></div>
						</td>
					</tr>
					</tfoot>
				<?php
				}
				?>
			</table>
			<?php
		}
	}
}
